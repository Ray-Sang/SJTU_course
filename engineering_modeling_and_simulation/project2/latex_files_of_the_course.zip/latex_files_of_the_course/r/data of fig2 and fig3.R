library(sysfonts)
font_add(family = "SimSun", regular = "/Users/lxc/Library/Fonts/SimSun.ttf")

number <- c(5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
rwmean <- c(0.0768,0.2356,0.4232,0.5887,0.7172,0.8145,0.8575,0.8856,
            0.9004,0.9076,0.9098,0.9059,0.9012,0.8959,0.8873,0.8830)
etmean <- c(9634.79,19186.35,28290.73,36926.01,44511.99,50779.15,56071.58,60167.22,
            63185.03,65357.24,66811.16,67843.25,68343.68,68459.23,68199.87,67649.01)

plot(number,rwmean, family="SimSun",
     xlab="节点数量", ylab="可靠性", 
     type="b",lty=2, pch=16,col="red")
title(main = "可靠性随节点数量的变化关系", family="SimSun")

plot(number,etmean, family="SimSun",
     xlab="节点数量", ylab="系统工作寿命", 
     type="b",lty=2, pch=16,col="green")
title(main = "系统工作寿命随节点数量的变化关系", family="SimSun")